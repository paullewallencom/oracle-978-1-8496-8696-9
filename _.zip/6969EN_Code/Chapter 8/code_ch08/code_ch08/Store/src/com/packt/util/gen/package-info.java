@javax.xml.bind.annotation.XmlSchema(namespace = "http://com.packt.wls12c")
package com.packt.util.gen;
